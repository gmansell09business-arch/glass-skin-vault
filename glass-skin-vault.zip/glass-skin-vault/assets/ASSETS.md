# Assets Folder

Place your high-fidelity images in this folder. The application expects the following files:

## Required Images

### Hero & Banners
| Filename | Description | Size | Notes |
|----------|-------------|------|-------|
| `hero-duo.jpg` | K/J-Beauty model(s) | 900×600px | Main landing page hero |
| `ingredients-banner.jpg` | Botanical/lab macro | 1200×400px | Ingredients page banner |

### Ingredient Macro Photography
| Filename | Description | Size |
|----------|-------------|------|
| `niacinamide.jpg` | White powder/crystals | 400×400px |
| `ginseng.jpg` | Ginseng root close-up | 400×400px |
| `hyaluronic.jpg` | Gel texture/serum | 400×400px |
| `salicylic.jpg` | Scientific aesthetic | 400×400px |
| `rice.jpg` | Rice grains/powder | 400×400px |
| `centella.jpg` | Centella asiatica leaves | 400×400px |
| `retinol.jpg` | Amber dropper bottle | 400×400px |
| `green-tea.jpg` | Green tea leaves | 400×400px |

### Product & Kit Photography
| Filename | Description | Size |
|----------|-------------|------|
| `am-glow-kit.jpg` | AM products flat-lay | 600×400px |
| `pm-restore-kit.jpg` | PM products arrangement | 600×400px |
| `cleanser.jpg` | Cleanser bottle/tube | 400×400px |
| `toner.jpg` | Toner bottle | 400×400px |
| `serum.jpg` | Serum with dropper | 400×400px |
| `moisturizer.jpg` | Moisturizer jar | 400×400px |
| `sunscreen.jpg` | Sunscreen tube | 400×400px |
| `mask.jpg` | Sheet or clay mask | 400×400px |
| `tool.jpg` | Skincare tool/device | 400×400px |

## Image Guidelines

1. **Format**: JPG preferred for photos, PNG for graphics
2. **Quality**: High resolution, optimized for web (aim for <200KB per image)
3. **Style**: Clean, minimal backgrounds. Soft lighting. K-Beauty aesthetic.
4. **Color Palette**: Neutral whites, soft greens, natural earth tones

## Fallback Behavior

If local images are not found, the app automatically falls back to Unsplash placeholder images. This ensures the app works without any assets during development.

## Recommended Sources

- [Unsplash](https://unsplash.com) - Free high-quality photos
- [Pexels](https://pexels.com) - Free stock photos
- Custom photography for production use

---

**Note**: Remember to optimize all images before adding to reduce load times.
